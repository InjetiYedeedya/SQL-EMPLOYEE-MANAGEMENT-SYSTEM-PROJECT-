-- ====================================================================================

--                       Project - Employee Tracker

-- ====================================================================================

create database employee_tracker;
use employee_tracker;

-- Table 1: Job Department
CREATE TABLE JobDepartment (
    Job_ID INT PRIMARY KEY,
    jobdept VARCHAR(50),
    name VARCHAR(100),
    description TEXT,
    salaryrange VARCHAR(50)
);
SELECT * FROM JobDepartment;

-- Table 2: Salary/Bonus
CREATE TABLE SalaryBonus (
    salary_ID INT PRIMARY KEY,
    Job_ID INT,
    amount DECIMAL(10,2),
    annual DECIMAL(10,2),
    bonus DECIMAL(10,2),
    CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
SELECT * FROM SalaryBonus;

-- Table 3: Employee
CREATE TABLE Employee (
    emp_ID INT PRIMARY KEY,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    gender VARCHAR(10),
    age INT,
    contact_add VARCHAR(100),
    emp_email VARCHAR(100) UNIQUE,
    emp_pass VARCHAR(50),
    Job_ID INT,
    CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
        REFERENCES JobDepartment(Job_ID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);
SELECT * FROM Employee;

-- Table 4: Qualification
CREATE TABLE Qualification (
    QualID INT PRIMARY KEY,
    Emp_ID INT,
    Position VARCHAR(50),
    Requirements VARCHAR(255),
    Date_In DATE,
    CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
        REFERENCES Employee(emp_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);



-- Table 5: Leaves
CREATE TABLE Leaves (
    leave_ID INT PRIMARY KEY,
    emp_ID INT,
    date DATE,
    reason TEXT,
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Table 6: Payroll
CREATE TABLE Payroll (
    payroll_ID INT PRIMARY KEY,
    emp_ID INT,
    job_ID INT,
    salary_ID INT,
    leave_ID INT,
    date DATE,
    report TEXT,
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES SalaryBonus(salary_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);

SELECT * FROM JobDepartment LIMIT 10;
SELECT * FROM SalaryBonus LIMIT 10;
SELECT * FROM Employee LIMIT 10;
SELECT * FROM Qualification LIMIT 10;
SELECT * FROM Leaves LIMIT 10;
SELECT * FROM Payroll LIMIT 10;


--           1. EMPLOYEE INSIGHTS
-- 1.	How many unique employees are currently in the system?
select count(distinct e.emp_id) as Total_employees from employee e;



-- 2. 	Which departments have the highest number of employees?

-- 3. 	What is the average salary per department?

-- 4.	Who are the top 5 highest-paid employees?

-- 5. 	What is the total salary expenditure across the company?

--			2. JOB ROLE AND DEPARTMENT ANALYSIS
-- 1.	How many different job roles exist in each department?

-- 2. 	What is the average salary range per department?

-- 3. 	Which job roles offer the highest salary?

-- 4. 	Which departments have the highest total salary allocation?
--          3. QUALIFICATION AND SKILLS ANALYSIS
-- 1. 	How many employees have at least one qualification listed?

-- 2. 	Which positions require the most qualifications?

-- 3.	Which employees have the highest number of qualifications?

--			4. LEAVE AND ABSENCE PATTERNS
-- 1.	Which year had the most employees taking leaves?

-- 2. 	What is the average number of leave days taken by its employees per department?

-- 3.	Which employees have taken the most leaves?

-- 4.	What is the total number of leave days taken company-wide?

-- 5. 	How do leave days correlate with payroll amounts?

--          5. PAYROLL AND COMPENSATION ANALYSIS
-- 1.	What is the total monthly payroll processed?

-- 2. 	What is the average bonus given per department?

-- 3.	Which department receives the highest total bonuses?

-- 4.	What is the average value of total_amount after considering leave deductions?

--			6. EMPLOYEE PERFORMANCE AND GROWTH
-- 1.	Which year had the highest number of employee promotions?































































-- ----------------------------------------------------------------------------------------------------------------
-- 					1. EMPLOYEE INSIGHTS
-- 1.	How many unique employees are currently in the system?
select firstname, lastname, count(*) as unique_emp from EMPLOYEE
group by firstname,lastname;
-- there are 60 unique employes
select count(*) as unique_employees from Employee;-- displays total no of employees

desc JobDepartment;

-- 2.	Which departments have the highest number of employees?
select JobDepartment.Jobdept as job_type, count(employee.emp_id) as no_of_emp_in_dept from JobDepartment
join employee on jobdepartment.Job_ID = employee.Job_ID 
group by jobdepartment.Jobdept 
order by no_of_emp_in_dept desc;

-- 3.	What is the average salary per department?


select jobdepartment.jobdept as department, avg(salarybonus.amount) as average_salary from SalaryBonus
join jobdepartment on salarybonus.job_id = jobdepartment.job_id
group by jobdepartment.jobdept
order by average_salary desc;








-- 4.	Who are the top 5 highest-paid employees?
desc employee;
select CONCAT(employee.firstname,' ',employee.lastname) as name, salarybonus.amount as salary from employee
join salarybonus on employee.job_id = salarybonus.job_id
order by salary desc limit 5;


-- 5.	What is the total salary expenditure across the company?
select sum(salarybonus.amount) as Total_salary_expenditure
from salarybonus;

-- -------------------------------------------------------------------------------------
-- 						2. JOB ROLE AND DEPARTMENT ANALYSIS

-- 1. 	How many different job roles exist in each department?

select * from jobdepartment;
select JobDepartment.jobdept as department, count(distinct JobDepartment.name) as roles from JobDepartment
group by JobDepartment.jobdept
order by roles desc;



-- 2.  	What is the average salary range per department?

select JobDepartment.jobdept as department, AVG(salarybonus.amount) as avarage_salary from jobdepartment
join salarybonus on JobDepartment.job_id = salarybonus.job_id
group by jobdepartment.jobdept 
order by avarage_salary desc;

SELECT 
    jobdept AS department,
    ROUND(AVG(CAST(SUBSTRING_INDEX(REPLACE(salaryrange, "$", ""), "-", 1) AS UNSIGNED))) AS avg_min_salary,
    ROUND(AVG(CAST(SUBSTRING_INDEX(REPLACE(salaryrange, "$", ""), "-", -1) AS UNSIGNED))) AS avg_max_salary
FROM JobDepartment
GROUP BY jobdept
ORDER BY avg_max_salary DESC;


-- 3. 	Which job roles offer the highest salary?
select JobDepartment.name as job_role, max(SalaryBonus.amount) as highest_salary from jobdepartment
join salarybonus on JobDepartment.Job_ID  = salarybonus.Job_ID 
group by jobdepartment.name 
order by highest_salary desc;

-- 4.	Which departments have the highest total salary allocation?

select jobdepartment.jobdept as department, sum(salarybonus.amount) as highest_total_salary from jobdepartment
join salarybonus on jobdepartment.job_id = salarybonus.job_id
group by jobdepartment.jobdept 
order by highest_total_salary desc;



-- 				3. QUALIFICATION AND SKILLS ANALYSIS
-- 1.	How many employees have at least one qualification listed?

select count(distinct employee.emp_id) as employees_with_qualification from employee 
join qualification on employee.emp_id = qualification.emp_id;

-- 						or

select concat(employee.firstname,' ',employee.lastname) as employees, 
count(qualification.qualid) as qualification from employee
join qualification on employee.emp_id = qualification.emp_id
group by employee.firstname,employee.lastname
order by qualification desc;

SELECT 
    CONCAT(employee.firstname, ' ', employee.lastname) AS employees, 
    COUNT(qualification.qualid) AS qualifications
FROM employee
JOIN qualification 
    ON employee.emp_id = qualification.emp_id
GROUP BY employee.emp_id, employee.firstname, employee.lastname
ORDER BY qualifications DESC;


-- 2. 	Which positions require the most qualifications?
SELECT 
    JobDepartment.name,
    COUNT(Qualification.qualid) AS total_qualifications
FROM Employee
JOIN JobDepartment 
    ON Employee.job_id = JobDepartment.job_id
JOIN Qualification 
    ON Employee.emp_id = Qualification.emp_id
GROUP BY JobDepartment.name
ORDER BY total_qualifications DESC;


-- 3.	Which employees have the highest number of qualifications?

SELECT 
    CONCAT(Employee.firstname, ' ', Employee.lastname) AS employee_name,
    COUNT(Qualification.qualid) AS total_qualifications
FROM Employee
JOIN Qualification 
    ON Employee.emp_id = Qualification.emp_id
GROUP BY Employee.emp_id, Employee.firstname, Employee.lastname
ORDER BY total_qualifications DESC;



--          4.  LEAVE AND ABSENCE PATTERNS
-- 1.	Which year had the most employees taking leaves?

select year(date) as year, count(distinct emp_id) as employees_taking_leaves from leaves
group by year(date)
order by employees_taking_leaves desc;


-- 2.	What is the average number of leave days taken by its employees per department?

SELECT jd.jobdept AS department, 
       COUNT(l.leave_ID) AS total_leave_days
FROM Leaves l
JOIN Employee e 
    ON l.emp_ID = e.emp_ID
JOIN JobDepartment jd 
    ON e.job_id = jd.job_id
GROUP BY jd.jobdept
ORDER BY total_leave_days DESC;





-- 3.	Which employees have taken the most leaves?
SELECT 
    Employee.emp_ID,
    Employee.name,
    JobDepartment.jobdept,
    COUNT(Leaves.leave_ID) AS total_leave_days
FROM Leaves
JOIN Employee 
    ON Leaves.emp_ID = Employee.emp_ID
JOIN JobDepartment 
    ON Employee.Job_ID = JobDepartment.Job_ID
GROUP BY Employee.emp_ID, Employee.name, JobDepartment.jobdept
ORDER BY total_leave_days DESC;

-- 4.	What is the total number of leave days taken company-wide?

-- 5.	How do leave days correlate with payroll amounts






















--           4. LEAVE AND ABSENCE PATTERNS
-- 1.	Which year had the most employees taking leaves?
select * from leaves;

SELECT YEAR(`date`) AS yr, COUNT(*) AS total_leaves
FROM Leaves
GROUP BY YEAR(`date`)
ORDER BY total_leaves DESC
LIMIT 1;



-- 2.	What is the average number of leave days taken by its employees per department?
SELECT COUNT(*) AS total_leave_days
FROM Leaves;
SELECT jd.jobdept AS department, 
       COUNT(l.leave_ID) AS total_leave_days
FROM Leaves l
JOIN Employee e 
    ON l.emp_ID = e.emp_ID
JOIN JobDepartment jd 
    ON e.job_id = jd.job_id
GROUP BY jd.jobdept
ORDER BY total_leave_days DESC;

SELECT 
    JobDepartment.jobdept AS department,
    AVG(leave_count) AS average_leave_days
FROM (
    SELECT 
        emp_ID,
        COUNT(*) AS leave_count
    FROM 
        Leaves
    GROUP BY 
        emp_ID
) AS leave_summary
JOIN Employee ON leave_summary.emp_ID = Employee.emp_ID
JOIN JobDepartment ON Employee.Job_ID = JobDepartment.Job_ID
GROUP BY 
    JobDepartment.jobdept
ORDER BY 
    average_leave_days DESC;

-- 3.	Which employees have taken the most leaves?

-- 4.	What is the total number of leave days taken company-wide?

-- 5.	How do leave days correlate with payroll amounts?






-- 4. LEAVE AND ABSENCE PATTERNS
-- Which year(month) had the most employees taking leaves?
select monthname(date),count(leave_id) as leave_count
from leaves
group by monthname(date)
order by leave_count desc
limit 1;

-- What is the average number of leave days taken by its employees per department?
select j.jobdept,avg(leave_id)
from employee e 
join jobdepartment j on e.job_id=j.job_id
join leaves l on e.emp_id=l.emp_id 
group by j.jobdept;

-- Which employees have taken the most leaves?
select e.firstname,e.lastname,count(leave_id) as no_of_leaves
from employee e 
join leaves l
on e.emp_id=l.emp_id
group by e.firstname,e.lastname;

-- What is the total number of leave days taken company-wide(dept wide)?

select j.jobdept,count(leave_id) as no_of_leaves
from employee e 
join jobdepartment j on e.job_id=j.job_id
join leaves l on e.emp_id=l.emp_id 
group by j.jobdept;

-- What is the average number of leave days taken by its employees per department?
SELECT 
    jobdept,
    AVG(leave_days) AS avg_leave_days
FROM (
    SELECT 
        e.emp_id,
        j.jobdept,
        COUNT(*) AS leave_days
    FROM employee e
    JOIN jobdepartment j 
        ON e.job_id = j.job_id
    JOIN leaves l 
        ON e.emp_id = l.emp_id
    GROUP BY e.emp_id, j.jobdept, l.leave_id
) AS per_leave
GROUP BY jobdept;

-- How do leave days correlate with payroll amounts?
SELECT p.emp_ID,
       COUNT(l.leave_ID) AS total_leave_days,
       round(AVG(p.total_amount),2) AS avg_payroll
FROM payroll p
LEFT JOIN leaves l ON p.leave_ID = l.leave_ID AND p.emp_ID = l.emp_ID
GROUP BY p.emp_ID;




select * from employee;

select * from jobdepartment j ;

select * from qualification q ;

select * from employee;

select * from leaves;

select * from salarybonus s ;

select * from payroll p ;

